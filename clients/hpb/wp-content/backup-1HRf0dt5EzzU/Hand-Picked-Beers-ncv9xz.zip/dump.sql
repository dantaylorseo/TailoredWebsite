/**
 * SQL Dump created with Backup for WordPress
 *
 * http://hel.io/wordpress/backup
 */

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

/* Dump of table `hpb_commentmeta`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_commentmeta`;

CREATE TABLE `hpb_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/* Dump of table `hpb_comments`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_comments`;

CREATE TABLE `hpb_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/* Dump of table `hpb_links`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_links`;

CREATE TABLE `hpb_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/* Dump of table `hpb_options`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_options`;

CREATE TABLE `hpb_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3151 DEFAULT CHARSET=utf8;

LOCK TABLES `hpb_options` WRITE;
/*!40000 ALTER TABLE `hpb_options` DISABLE KEYS */;

INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 4, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 5, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 6, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 7, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 8, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 9, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 10, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 11, '', 10, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 12, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 13, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 14, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 15, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 16, '', 110, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 17, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 18, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 19, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 20, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 21, '', 10, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 22, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 23, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 24, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 28, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 29, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 30, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 31, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 32, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 33, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 34, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 35, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2986, '', 1411810967, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2987, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 36, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 37, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 38, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 39, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 40, '', 2, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 41, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 42, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 43, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 44, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 45, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 46, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 47, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 48, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 49, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 50, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 51, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 52, '', 29630, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 53, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 54, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 55, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 56, '', 2, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 57, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 58, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 59, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 60, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 61, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 62, '', 150, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 63, '', 150, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 64, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 65, '', 300, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 66, '', 300, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 67, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 68, '', 1024, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 69, '', 1024, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 70, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 71, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 72, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 73, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 74, '', 14, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 75, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 76, '', 5, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 77, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 78, '', 50, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 79, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 80, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 81, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 82, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 83, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 84, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 85, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 86, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 87, '', 10, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 88, '', 5, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 89, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 90, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 91, '', 22441, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 92, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 93, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 94, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 95, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 96, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 97, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 98, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 99, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 108, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2423, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1617, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1619, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 145, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 146, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 147, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 148, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3121, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 154, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 158, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3025, '', 1412336129, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3008, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 342, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 343, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3131, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 344, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 345, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 346, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 670, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3101, '', 1412376477, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3102, '', 1412333277, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3117, '', 1412337916, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3118, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3149, '', 1412423063, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3150, '', 1412336663, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3108, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3109, '', 1412376479, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3110, '', 1412333279, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3113, '', 1412376479, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3114, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3111, '', 1412419689, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3112, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3095, '', 1412938073, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 667, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 677, '', 1.0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 623, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 671, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 675, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 676, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 622, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1036, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1552, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3089, '', 1412334924, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3090, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1066, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1067, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1069, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1070, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2435, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1634, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1635, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1636, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3093, '', 1412419672, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3094, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2120, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3091, '', 1412336726, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3092, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2611, '', 1414962870, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2612, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3039, '', 1411769863, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3040, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3096, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3097, '', 1412419673, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3098, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2981, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2985, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2983, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2620, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2621, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2622, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2623, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2624, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2625, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2626, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2627, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2628, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2629, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2630, '', 2, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2631, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2632, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2633, '', 125, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2634, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2635, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2636, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2637, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2638, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2639, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2640, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2641, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2642, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2643, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2644, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2645, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2646, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2647, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2648, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2649, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2650, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2651, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2652, '', 60, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2653, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2654, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2655, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2656, '', 2, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2657, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2658, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2659, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2660, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2661, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2662, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2663, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2664, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2665, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2666, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2667, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2668, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2669, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2670, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2671, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2672, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2673, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2674, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2675, '', 126, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2676, '', 127, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2677, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2678, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2679, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2680, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2681, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2682, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2683, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2684, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2685, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2686, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2687, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2688, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2689, '', 128, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2690, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2691, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2692, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2693, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2694, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2695, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2696, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2697, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2698, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2699, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2700, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2701, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2702, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2703, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2704, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2705, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2706, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2707, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2709, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2710, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2722, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2721, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2716, '', 1439542606, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2717, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2728, '', 1, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3041, '', 1411769863, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3042, '', 1411726663, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3043, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3044, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3045, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3046, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3047, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3048, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3049, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3115, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3116, '', 1412507085, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3105, '', 1412376478, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3106, '', 1412333278, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2737, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2792, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2793, '', 1439545696, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2794, '', 0, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2795, '', 1439545696, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2796, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2753, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3099, '', 1412376477, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3100, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3103, '', 1412376478, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3104, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3107, '', 1412376479, '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2989, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3012, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2994, '', '', '' );
INSERT INTO `hpb_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2995, '', '', '' );

/*!40000 ALTER TABLE `hpb_options` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_postmeta`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_postmeta`;

CREATE TABLE `hpb_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=740 DEFAULT CHARSET=utf8;

LOCK TABLES `hpb_postmeta` WRITE;
/*!40000 ALTER TABLE `hpb_postmeta` DISABLE KEYS */;

INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 309, 66, '', 1 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 4, 13, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 5, 13, '', 0 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 6, 13, '', 11 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 7, 13, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 8, 13, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 9, 13, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 10, 13, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 11, 13, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 67, 5, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 13, 14, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 14, 14, '', 0 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 15, 14, '', 10 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 16, 14, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 17, 14, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 18, 14, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 19, 14, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 20, 14, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 22, 15, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 23, 15, '', 0 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 24, 15, '', 9 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 25, 15, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 26, 15, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 27, 15, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 28, 15, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 29, 15, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 31, 16, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 32, 16, '', 0 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 33, 16, '', 8 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 34, 16, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 35, 16, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 36, 16, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 37, 16, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 38, 16, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 731, 146, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 730, 143, '', 1 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 729, 143, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 728, 141, '', 1 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 727, 141, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 49, 18, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 50, 18, '', 0 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 51, 18, '', 6 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 52, 18, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 53, 18, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 54, 18, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 55, 18, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 56, 18, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 58, 19, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 59, 19, '', 0 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 60, 19, '', 5 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 61, 19, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 62, 19, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 63, 19, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 64, 19, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 65, 19, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 68, 5, '', 1 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 91, 34, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 92, 34, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 715, 7, '', 1411725552 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 714, 7, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 194, 45, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 195, 45, '', 0 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 196, 45, '', 44 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 197, 45, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 198, 45, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 199, 45, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 200, 45, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 201, 45, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 240, 41, '', 1 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 203, 46, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 204, 46, '', 0 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 205, 46, '', 43 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 206, 46, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 207, 46, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 208, 46, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 209, 46, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 210, 46, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 241, 42, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 212, 47, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 213, 47, '', 0 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 214, 47, '', 42 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 215, 47, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 216, 47, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 217, 47, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 218, 47, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 219, 47, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 242, 42, '', 1 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 221, 48, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 222, 48, '', 0 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 223, 48, '', 41 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 224, 48, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 225, 48, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 226, 48, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 227, 48, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 228, 48, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 230, 49, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 231, 49, '', 0 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 232, 49, '', 11 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 233, 49, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 234, 49, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 235, 49, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 236, 49, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 237, 49, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 239, 41, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 246, 54, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 247, 54, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 738, 131, '', 106 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 712, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 711, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 710, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 521, 90, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 734, 149, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 736, 152, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 251, 57, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 252, 57, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 709, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 708, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 707, 131, '', 10.50 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 706, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 705, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 520, 90, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 256, 60, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 257, 60, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 704, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 703, 131, '', 123 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 702, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 701, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 700, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 518, 89, '', 1 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 270, 61, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 271, 61, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 699, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 698, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 697, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 696, 131, '', 10.50 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 272, 62, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 273, 62, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 695, 131, '', 15.00 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 692, 131, '', 0 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 693, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 694, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 294, 9, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 295, 9, '', 1 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 323, 66, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 502, 62, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 504, 8, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 508, 85, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 716, 125, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 717, 125, '', 1 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 718, 140, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 719, 140, '', 0 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 720, 140, '', 125 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 721, 140, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 722, 140, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 723, 140, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 507, 85, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 585, 106, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 691, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 690, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 584, 106, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 519, 89, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 522, 89, '', 90 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 535, 11, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 536, 11, '', 1 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 549, 93, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 550, 93, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 737, 152, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 551, 94, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 552, 94, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 557, 96, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 558, 96, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 689, 131, '', 1 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 688, 131, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 559, 8, '', 1 );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 732, 146, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 725, 140, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 724, 140, '', '' );
INSERT INTO `hpb_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 739, 153, '', '' );

/*!40000 ALTER TABLE `hpb_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_posts`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_posts`;

CREATE TABLE `hpb_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=154 DEFAULT CHARSET=utf8;

LOCK TABLES `hpb_posts` WRITE;
/*!40000 ALTER TABLE `hpb_posts` DISABLE KEYS */;

INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 66, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 5, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 1, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 134, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 5, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 135, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 5, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 6, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 2, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 7, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 3, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 8, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 4, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 137, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 8, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 9, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 5, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 10, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 6, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 11, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 7, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 13, 1, '', '', '', '', '', '', '', '', '', 13, '', '', '', '', '', 0, '', 7, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 14, 1, '', '', '', '', '', '', '', '', '', 14, '', '', '', '', '', 0, '', 6, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 15, 1, '', '', '', '', '', '', '', '', '', 15, '', '', '', '', '', 0, '', 5, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 16, 1, '', '', '', '', '', '', '', '', '', 16, '', '', '', '', '', 0, '', 4, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 141, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 18, 1, '', '', '', '', '', '', '', '', '', 18, '', '', '', '', '', 0, '', 2, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 19, 1, '', '', '', '', '', '', '', '', '', 19, '', '', '', '', '', 0, '', 1, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 20, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 5, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 147, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 66, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 138, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 7, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 139, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 125, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 140, 1, '', '', '', '', '', '', '', '', '', 140, '', '', '', '', '', 0, '', 3, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 142, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 141, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 143, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 144, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 143, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 34, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 41, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 8, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 42, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 9, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 43, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 10, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 44, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 11, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 45, 1, '', '', '', '', '', '', '', '', '', 45, '', '', '', '', '', 0, '', 4, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 46, 1, '', '', '', '', '', '', '', '', '', 46, '', '', '', '', '', 0, '', 3, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 47, 1, '', '', '', '', '', '', '', '', '', 47, '', '', '', '', '', 0, '', 2, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 48, 1, '', '', '', '', '', '', '', '', '', 48, '', '', '', '', '', 0, '', 1, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 49, 1, '', '', '', '', '', '', '', '', '', 49, '', '', '', '', '', 0, '', 5, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 50, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 41, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 51, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 42, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 52, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 42, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 54, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 90, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 89, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 57, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 91, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 89, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 92, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 11, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 60, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 61, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 62, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 63, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 9, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 64, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 9, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 89, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 81, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 9, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 93, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 85, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 94, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 146, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 5, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 106, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 5, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 96, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 97, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 8, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 136, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 8, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 145, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 133, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 5, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 124, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 125, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 126, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 127, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 128, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 131, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 148, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 131, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 149, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 150, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 66, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 151, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 66, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 152, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 131, '', 0, '', '', 0 );
INSERT INTO `hpb_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 153, 1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );

/*!40000 ALTER TABLE `hpb_posts` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_rg_form`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_rg_form`;

CREATE TABLE `hpb_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

LOCK TABLES `hpb_rg_form` WRITE;
/*!40000 ALTER TABLE `hpb_rg_form` DISABLE KEYS */;

INSERT INTO `hpb_rg_form` ( id, title, date_created, is_active ) VALUES ( 1, '', '', 1 );

/*!40000 ALTER TABLE `hpb_rg_form` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_rg_form_meta`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_rg_form_meta`;

CREATE TABLE `hpb_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext,
  `entries_grid_meta` longtext,
  PRIMARY KEY (`form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `hpb_rg_form_meta` WRITE;
/*!40000 ALTER TABLE `hpb_rg_form_meta` DISABLE KEYS */;

INSERT INTO `hpb_rg_form_meta` ( form_id, display_meta, entries_grid_meta ) VALUES ( 1, '', NULL );

/*!40000 ALTER TABLE `hpb_rg_form_meta` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_rg_form_view`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_rg_form_view`;

CREATE TABLE `hpb_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

LOCK TABLES `hpb_rg_form_view` WRITE;
/*!40000 ALTER TABLE `hpb_rg_form_view` DISABLE KEYS */;

INSERT INTO `hpb_rg_form_view` ( id, form_id, date_created, ip, count ) VALUES ( 1, 1, '', '', 1 );
INSERT INTO `hpb_rg_form_view` ( id, form_id, date_created, ip, count ) VALUES ( 2, 1, '', '', 1 );
INSERT INTO `hpb_rg_form_view` ( id, form_id, date_created, ip, count ) VALUES ( 3, 1, '', '', 1 );
INSERT INTO `hpb_rg_form_view` ( id, form_id, date_created, ip, count ) VALUES ( 4, 1, '', '', 1 );
INSERT INTO `hpb_rg_form_view` ( id, form_id, date_created, ip, count ) VALUES ( 5, 1, '', '', 1 );
INSERT INTO `hpb_rg_form_view` ( id, form_id, date_created, ip, count ) VALUES ( 6, 1, '', '', 2 );

/*!40000 ALTER TABLE `hpb_rg_form_view` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_rg_lead`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_rg_lead`;

CREATE TABLE `hpb_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) NOT NULL,
  `source_url` varchar(200) NOT NULL DEFAULT '',
  `user_agent` varchar(250) NOT NULL DEFAULT '',
  `currency` varchar(5) DEFAULT NULL,
  `payment_status` varchar(15) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `transaction_id` varchar(50) DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

LOCK TABLES `hpb_rg_lead` WRITE;
/*!40000 ALTER TABLE `hpb_rg_lead` DISABLE KEYS */;

INSERT INTO `hpb_rg_lead` ( id, form_id, post_id, date_created, is_starred, is_read, ip, source_url, user_agent, currency, payment_status, payment_date, payment_amount, transaction_id, is_fulfilled, created_by, transaction_type, status ) VALUES ( 1, 1, NULL, '', 0, 0, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '' );

/*!40000 ALTER TABLE `hpb_rg_lead` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_rg_lead_detail`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_rg_lead_detail`;

CREATE TABLE `hpb_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

LOCK TABLES `hpb_rg_lead_detail` WRITE;
/*!40000 ALTER TABLE `hpb_rg_lead_detail` DISABLE KEYS */;

INSERT INTO `hpb_rg_lead_detail` ( id, lead_id, form_id, field_number, value ) VALUES ( 1, 1, 1, 1.3, '' );
INSERT INTO `hpb_rg_lead_detail` ( id, lead_id, form_id, field_number, value ) VALUES ( 2, 1, 1, 1.6, '' );
INSERT INTO `hpb_rg_lead_detail` ( id, lead_id, form_id, field_number, value ) VALUES ( 3, 1, 1, 2, '' );
INSERT INTO `hpb_rg_lead_detail` ( id, lead_id, form_id, field_number, value ) VALUES ( 4, 1, 1, 3, '' );

/*!40000 ALTER TABLE `hpb_rg_lead_detail` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_rg_lead_detail_long`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_rg_lead_detail_long`;

CREATE TABLE `hpb_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/* Dump of table `hpb_rg_lead_meta`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_rg_lead_meta`;

CREATE TABLE `hpb_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`),
  KEY `lead_id` (`lead_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/* Dump of table `hpb_rg_lead_notes`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_rg_lead_notes`;

CREATE TABLE `hpb_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/* Dump of table `hpb_term_relationships`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_term_relationships`;

CREATE TABLE `hpb_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `hpb_term_relationships` WRITE;
/*!40000 ALTER TABLE `hpb_term_relationships` DISABLE KEYS */;

INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 19, 2, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 18, 2, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 66, 22, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 16, 2, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 15, 2, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 14, 2, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 13, 2, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 131, 23, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 48, 15, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 47, 15, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 46, 15, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 45, 15, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 49, 15, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 131, 18, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 140, 2, 0 );
INSERT INTO `hpb_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 131, 3, 0 );

/*!40000 ALTER TABLE `hpb_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_term_taxonomy`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_term_taxonomy`;

CREATE TABLE `hpb_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

LOCK TABLES `hpb_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `hpb_term_taxonomy` DISABLE KEYS */;

INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 1, 1, '', '', 0, 0 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 2, 2, '', '', 0, 7 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 3, 3, '', '', 0, 1 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 4, 4, '', '', 0, 0 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 5, 5, '', '', 0, 0 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 6, 6, '', '', 0, 0 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 7, 7, '', '', 0, 0 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 8, 8, '', '', 0, 0 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 23, 23, '', '', 0, 1 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 22, 22, '', '', 0, 1 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 21, 21, '', '', 0, 0 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 20, 20, '', '', 0, 0 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 19, 19, '', '', 0, 0 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 15, 15, '', '', 0, 5 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 16, 16, '', '', 0, 0 );
INSERT INTO `hpb_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 18, 18, '', '', 0, 1 );

/*!40000 ALTER TABLE `hpb_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_terms`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_terms`;

CREATE TABLE `hpb_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

LOCK TABLES `hpb_terms` WRITE;
/*!40000 ALTER TABLE `hpb_terms` DISABLE KEYS */;

INSERT INTO `hpb_terms` ( term_id, name, slug, term_group ) VALUES ( 1, '', '', 0 );
INSERT INTO `hpb_terms` ( term_id, name, slug, term_group ) VALUES ( 2, '', '', 0 );
INSERT INTO `hpb_terms` ( term_id, name, slug, term_group ) VALUES ( 23, '', '', 0 );
INSERT INTO `hpb_terms` ( term_id, name, slug, term_group ) VALUES ( 22, '', '', 0 );
INSERT INTO `hpb_terms` ( term_id, name, slug, term_group ) VALUES ( 21, '', '', 0 );
INSERT INTO `hpb_terms` ( term_id, name, slug, term_group ) VALUES ( 20, '', '', 0 );
INSERT INTO `hpb_terms` ( term_id, name, slug, term_group ) VALUES ( 15, '', '', 0 );
INSERT INTO `hpb_terms` ( term_id, name, slug, term_group ) VALUES ( 19, '', '', 0 );
INSERT INTO `hpb_terms` ( term_id, name, slug, term_group ) VALUES ( 18, '', '', 0 );

/*!40000 ALTER TABLE `hpb_terms` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_thumbnail_slider`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_thumbnail_slider`;

CREATE TABLE `hpb_thumbnail_slider` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) NOT NULL,
  `image_name` varchar(500) NOT NULL,
  `createdon` datetime NOT NULL,
  `custom_link` varchar(1000) DEFAULT NULL,
  `post_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

LOCK TABLES `hpb_thumbnail_slider` WRITE;
/*!40000 ALTER TABLE `hpb_thumbnail_slider` DISABLE KEYS */;

INSERT INTO `hpb_thumbnail_slider` ( id, title, image_name, createdon, custom_link, post_id ) VALUES ( 7, '', '', '', '', NULL );
INSERT INTO `hpb_thumbnail_slider` ( id, title, image_name, createdon, custom_link, post_id ) VALUES ( 8, '', '', '', '', NULL );
INSERT INTO `hpb_thumbnail_slider` ( id, title, image_name, createdon, custom_link, post_id ) VALUES ( 9, '', '', '', '', NULL );
INSERT INTO `hpb_thumbnail_slider` ( id, title, image_name, createdon, custom_link, post_id ) VALUES ( 10, '', '', '', '', NULL );

/*!40000 ALTER TABLE `hpb_thumbnail_slider` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_usermeta`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_usermeta`;

CREATE TABLE `hpb_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;

LOCK TABLES `hpb_usermeta` WRITE;
/*!40000 ALTER TABLE `hpb_usermeta` DISABLE KEYS */;

INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 1, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 2, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 3, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 4, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 5, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 6, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 7, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 8, 1, '', 0 );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 9, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 10, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 11, 1, '', 10 );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 12, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 13, 1, '', 1 );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 14, 1, '', 145 );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 15, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 16, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 17, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 18, 1, '', 1412335672 );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 19, 1, '', 2 );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 20, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 21, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 22, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 23, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 24, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 25, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 26, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 27, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 28, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 29, 2, '', 0 );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 30, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 31, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 32, 2, '', 10 );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 33, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 34, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 35, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 36, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 37, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 38, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 39, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 40, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 41, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 42, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 43, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 44, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 45, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 46, 2, '', 102 );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 47, 1, '', 1408005773 );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 48, 2, '', 1412336578 );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 49, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 52, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 50, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 51, 1, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 53, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 54, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 55, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 56, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 57, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 58, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 59, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 60, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 61, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 62, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 63, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 64, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 65, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 66, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 67, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 68, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 69, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 70, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 71, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 72, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 73, 2, '', '' );
INSERT INTO `hpb_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 74, 2, '', '' );

/*!40000 ALTER TABLE `hpb_usermeta` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_users`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_users`;

CREATE TABLE `hpb_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

LOCK TABLES `hpb_users` WRITE;
/*!40000 ALTER TABLE `hpb_users` DISABLE KEYS */;

INSERT INTO `hpb_users` ( ID, user_login, user_pass, user_nicename, user_email, user_url, user_registered, user_activation_key, user_status, display_name ) VALUES ( 1, '', '', '', '', '', '', '', 0, '' );
INSERT INTO `hpb_users` ( ID, user_login, user_pass, user_nicename, user_email, user_url, user_registered, user_activation_key, user_status, display_name ) VALUES ( 2, '', '', '', '', '', '', '', 0, '' );

/*!40000 ALTER TABLE `hpb_users` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_woocommerce_attribute_taxonomies`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_woocommerce_attribute_taxonomies`;

CREATE TABLE `hpb_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) NOT NULL,
  `attribute_label` longtext,
  `attribute_type` varchar(200) NOT NULL,
  `attribute_orderby` varchar(200) NOT NULL,
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/* Dump of table `hpb_woocommerce_downloadable_product_permissions`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_woocommerce_downloadable_product_permissions`;

CREATE TABLE `hpb_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `download_id` varchar(32) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL DEFAULT '0',
  `order_key` varchar(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `downloads_remaining` varchar(9) DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`,`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/* Dump of table `hpb_woocommerce_order_itemmeta`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_woocommerce_order_itemmeta`;

CREATE TABLE `hpb_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/* Dump of table `hpb_woocommerce_order_items`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_woocommerce_order_items`;

CREATE TABLE `hpb_woocommerce_order_items` (
  `order_item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_name` longtext NOT NULL,
  `order_item_type` varchar(200) NOT NULL DEFAULT '',
  `order_id` bigint(20) NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/* Dump of table `hpb_woocommerce_tax_rate_locations`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_woocommerce_tax_rate_locations`;

CREATE TABLE `hpb_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `location_code` varchar(255) NOT NULL,
  `tax_rate_id` bigint(20) NOT NULL,
  `location_type` varchar(40) NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type` (`location_type`),
  KEY `location_type_code` (`location_type`,`location_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/* Dump of table `hpb_woocommerce_tax_rates`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_woocommerce_tax_rates`;

CREATE TABLE `hpb_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) NOT NULL DEFAULT '',
  `tax_rate` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) NOT NULL,
  `tax_rate_class` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`),
  KEY `tax_rate_class` (`tax_rate_class`),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/* Dump of table `hpb_woocommerce_termmeta`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_woocommerce_termmeta`;

CREATE TABLE `hpb_woocommerce_termmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `woocommerce_term_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `woocommerce_term_id` (`woocommerce_term_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

LOCK TABLES `hpb_woocommerce_termmeta` WRITE;
/*!40000 ALTER TABLE `hpb_woocommerce_termmeta` DISABLE KEYS */;

INSERT INTO `hpb_woocommerce_termmeta` ( meta_id, woocommerce_term_id, meta_key, meta_value ) VALUES ( 1, 23, '', 0 );
INSERT INTO `hpb_woocommerce_termmeta` ( meta_id, woocommerce_term_id, meta_key, meta_value ) VALUES ( 2, 23, '', 1 );

/*!40000 ALTER TABLE `hpb_woocommerce_termmeta` ENABLE KEYS */;
UNLOCK TABLES;

/* Dump of table `hpb_wp_email_capture_registered_members`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_wp_email_capture_registered_members`;

CREATE TABLE `hpb_wp_email_capture_registered_members` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `email` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/* Dump of table `hpb_wp_email_capture_temp_members`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `hpb_wp_email_capture_temp_members`;

CREATE TABLE `hpb_wp_email_capture_temp_members` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `email` text NOT NULL,
  `confirm_code` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
